# MCApollo
# "Trickster... Welcome to my Velvet Room" - Person

# ----- Pip support
if [[ -f /usr/local/bin/pip3.7 ]] || [[ -f /usr/local/bin/pip2.7 ]]; then

export TMPDIR=/usr/tmp/

fi

# ----- Golang support
if [[ -d /usr/local/libexec/go/ ]]; then

PATH="$PATH:/usr/local/libexec/go/bin/" # in this order so the go wrapper gets called.

fi

# ----- Generic
X="--sysroot=/usr/SDK -I/usr/local/include -I/usr/include -L/usr/local/lib -L/usr/lib"
# Set 'false' to 'true' if you need to compile on device.
if false; then
	if ! command -v cc >/dev/null; then
	export CC=clang	; fi # Command is a bash builtin, so we're not calling `which`
        if ! command -v c++ >/dev/null; then
        export CXX=clang++ ; fi

	export CFLAGS=$X
	export LDFLAGS=$X
	export CPPFLAGS=$X
	export CXXFLAGS=$X
fi
unset X
